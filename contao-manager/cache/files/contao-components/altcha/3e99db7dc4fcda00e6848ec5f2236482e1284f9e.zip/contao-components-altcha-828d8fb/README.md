ALTCHA
======

This is a customized package of the [ALTCHA][1] script to be integrated in
[Contao Open Source CMS][2].


[1]: https://altcha.org
[2]: https://contao.org
