Tablesort
=========

This is a customized package of the [tablesort][1] script to be integrated in
[Contao Open Source CMS][2].


[1]: https://tristen.ca/tablesort/
[2]: https://contao.org
