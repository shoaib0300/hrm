TinyMCE
=======

This is a customized package of the [TinyMCE][1] editor to be integrated in
[Contao Open Source CMS][2].


[1]: https://www.tiny.cloud
[2]: https://contao.org
